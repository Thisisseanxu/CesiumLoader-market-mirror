# 神秘插件（MysteryMode）

> ！？真的很神秘？！(组排玩家推荐)

只影响本机显示，不改服务器数据。关闭 mod 或把 `config.json` 的 `enabled` 改成 `false` 后会尽量还原。

## 效果

- **选人遮挡**：房间选人阶段，下方角色列表和上方四个玩家栏统一用「服务器BUG」事件卡遮挡，不再是黑框；遮挡层不接收触摸，仍可盲点。
- **自己换皮**：进入对局后，自己看到的角色模型、走路/攻击动画、侧边栏名字和头像都会变成另一个随机英雄；真实战斗数据不变。
- **队友换皮**：队友的模型会随机替换成不同地图的雅央系 Boss（科学怪人 / 天王寺雅央 / 嘎呜 / 学院安全官等）；局内查看队友的属性和技能面板会被隐藏。
- **手牌错乱**：每张手牌的卡面、名字、费用、说明都会随机显示成另一张牌；实际打出的效果仍是原来的牌。也可改成 `hide` 直接隐藏手牌。
- **步数隐藏**：骰子只显示空白骰子，隐藏点数；地图上的可达步数和移动虚线也隐藏，只保留选择方向用的箭头。
- **侦探事件伪装**：侦探技能选事件时，所有候选事件卡都显示成「小浣熊繁殖季」，确认选择后才由游戏揭示真实事件。
- **玩家/怪物匿名**：玩家侧边栏 ID 打码；所有怪物模型、名字、血量和面板统一变成【小偷】和 `?`，手动查看怪物也只会看到小偷面板。

## 配置

`config.json`：

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | `true` | 总开关 |
| `hideCharacterSelect` | `true` | 遮挡选人角色卡 |
| `cardMode` | `scramble` | `scramble` 卡面错乱；`hide` 直接隐藏手牌 |
| `hideMapSteps` | `true` | 隐藏地图步数 |
| `hideRoadLine` | `true` | 隐藏移动虚线和方向提示 |
| `hideDicePoint` | `true` | 隐藏骰子点数 |
| `maskPlayerId` | `true` | 遮挡玩家 ID |
| `disguiseMonsters` | `true` | 名字/血量/面板改成小偷 |
| `swapMonsterModel` | `true` | 怪物模型换成小偷模型 |
| `disguisePlayers` | `true` | 自己随机英雄、队友随机雅央 Boss |
| `maskDetectiveEvent` | `true` | 侦探选事件全部显示成小浣熊 |
| `monsterName` | `小偷` | 怪物显示名 |
| `monsterHpText` | `?` | 怪物血量显示 |
| `uiRefreshIntervalMs` | `200` | UI 重扫间隔（毫秒） |

## 构建

```powershell
dotnet build astral\dev\MysteryMode\MysteryMode.csproj -c Release
```

产物在 `bin\Release\netstandard2.0\MysteryMode.dll`。把 DLL、`MysteryMode.json`、`config.json` 和 `assets` 文件夹一起放进对应客户端的 mod 目录：

```text
# 中文客户端（CesiumLoader 3.x / SDK 3.5.2）
F:\steam\steamapps\common\Astral Party\8vJXn6CN\AstralParty_ModLoader\mods\MysteryMode\

# Toys 客户端（CesiumLoader 2.5.3）
F:\steam\steamapps\common\Astral Party\1\AstralParty_ModLoader\mods\MysteryMode\
```

两个目录当前都已放入一份构建产物。若 Toys 客户端提示 SDK 版本不兼容，请用该目录下的旧版 `CesiumLoader.SDK.dll` 重新编译后再放进去。
