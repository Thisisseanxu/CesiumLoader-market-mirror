# 获取账号凭据

作者：hpenguins · 版本：1.0.0

将当前登录账号的国服凭据保存到本机，供 AstralParty Toys 的「我的账号」功能读取角色参战次数和好友状态。

## 使用方法

1. 安装本 Mod，在模组页启用，并保持配置中的 `enabled` 为 `true`。
2. 启动游戏，正常登录并进入主界面。
3. Mod 自动保存当前账号的凭据：

   ```text
   游戏目录/AstralParty_ModLoader/usercredentials/<玩家 UID>/account.json
   ```

4. 完全退出游戏，在 Toys 的「我的账号」页点击「重新检查」，选择 UID，再点击「连接并获取」。

每个 UID 单独保存。登录信息变化或重新登录后，Mod 会在主界面更新凭据。关闭游戏、停用或卸载 Mod 不会自动删除已有凭据；不再需要时，可在 Toys 中删除当前账号的凭据。

## 凭据安全

**account.json 包含可用于登录账号的明文凭据，Base64 不是加密。请妥善保管，勿分享、公开上传、提交到代码仓库或同步到公共目录。**

本 Mod 不上传凭据，不发起网络请求，也不会代替用户登录。Toys 查询时由本机直接向官方游戏服务器认证，不向 Toys 或市场服务器发送凭据。同账号同时登录可能互踢，请先退出其它设备上的同账号会话。

## 配置

- `enabled`：默认 `true`。关闭后停止自动导出及本地认证交接，不删除已有文件。

## 兼容性与安装

- 适用于国服 China 认证渠道。
- 需要兼容 SDK 2.3.2 的 CesiumLoader。
- 权限：读取游戏状态、文件系统（`ReadGameState | FileSystem`）。
- 可通过 Toys 市场安装；手动安装时将整个 `AccountCredentialMod` 文件夹复制到 `AstralParty_ModLoader/mods/`。升级时保留已有 `config.json`。
- 游戏更新、重新登录或登录信息失效后，可能需要重新生成凭据。

## 本地认证交接

支持 `AstralParty_ModLoader/auth-handoff/` 的一次性 nonce 交接。客户端写入 `request.json`，其中包含新生成的 32 位小写十六进制 `nonce`；Mod 在登录主界面生成同 nonce 的 `response.json`。客户端应校验 nonce 和生成时间，使用后立即删除响应。响应在后续轮询中按 30 秒有效期清理；持久保存的 `usercredentials/<UID>/account.json` 不受该清理影响。
