# 原生变速（NativeSpeedMod）

通过 CesiumLoader 的原生时钟控制通道（`CESIUM_SPEED_PORT` 本地 UDP）在游戏内实时调整全游戏倍速，弥补内置 `SpeedHackMod` 切换为 Unity `timeScale` 加速后无法在游戏内动态调节原生加速倍率的问题，并**内置回合时钟补偿**，让原生加速时我方操作倒计时（如 30 秒思考窗口）及界面自动倒计时仍按真实时间流逝。

> [!WARNING]
> **不能与内置「变速」模组（`SpeedHackMod`）同时使用！**
>
> 内置 `SpeedHackMod`（3.0.0+）会在检测到原生倍率大于 `1.0x` 时主动将原生时钟重置回 `1.0x`。请务必在 **AstralParty.Toys** 中停用内置 `SpeedHackMod`（或禁用其中一个模组）。默认配置下，本模组一旦检测到 `SpeedHackMod` 存在，会在加载器控制台报错并自动关闭自身功能。

## 平台与依赖

- **支持平台**：仅 Windows（依赖加载器原生时间函数 hook 与 `CESIUM_SPEED_PORT` 通道）
- **最低加载器/SDK 版本**：CesiumLoader `4.1.2`（需保持加载器配置 `speedControlEnabled = true`）

## 使用方法（快捷键）

- `Delete`：在 `1.0x` 与切换前的记忆倍率之间来回切换
- `Alt + =`（或 `Alt + 小键盘 +`）：提高原生倍率
- `Alt + -`（或 `Alt + 小键盘 -`）：降低原生倍率

启动就绪后会自动恢复 `config.json` 中记录的倍率 `speed`（默认 `2.0x`）；在游戏内调整倍率停手 1.2 秒后会自动写回配置文件，卸载时恢复为 `1.0x`。

## 内置回合时钟

原生变速会同步加快游戏内部计时。开启 `turnClockEnabled`（默认开启）后，本模组会在每帧 `LateUpdate` 按当前原生倍率补偿客户端倒计时起点（仅调整客户端计时显示与自动超时窗口，不改变服务器操作期限）：

- 我方行动操作窗口（出牌 / 商店 / 技能选择等）
- 别人回合的倒计时显示（`turnClockOtherPlayers`）
- 选人界面自动确认倒计时（`turnClockHeroSelect`）
- 结算界面自动翻页倒计时（`turnClockSettlement`）
- 房间等待 / 防挂机踢出倒计时（`turnClockRoomWait`）
- 剧情自动播放翻页倒计时（`turnClockStoryAuto`）

若同时启用了外部 `TurnClockMod` 且外部模组已成功接管原生时钟补偿，本模组的内置回合时钟会自动让渡，避免重复补偿；若外部 `TurnClockMod` 未启用或未能识别原生通道，则由本模组直接接管补偿。

## 配置说明（`config.json`）

可通过 AstralParty.Toys 模组配置页直接编辑，保存后实时热重载：

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `speed` | `2.0` | 记住的当前倍速，启动时恢复（范围 `1.0–100.0`） |
| `speedStep` | `0.5` | 每次 `Alt + =` / `Alt + -` 增减的幅度 |
| `minSpeed` | `1.0` | 允许的最低倍速（硬下限 `1.0`，不支持减速） |
| `maxSpeed` | `10.0` | 允许的最高倍速（加载器硬上限 `100.0`，联机建议不超过 `3.0`） |
| `toggleKey` | `"Delete"` | 在 `1.0x` 与记忆倍率间切换的按键 |
| `speedUpKey` | `"Equals"` | 加速按键（需按住 `Alt`） |
| `speedDownKey` | `"Minus"` | 减速按键（需按住 `Alt`） |
| `useNumpadKeys` | `true` | 小键盘 `+` / `-` 是否也用于调速 |
| `notify` | `true` | 调速与冲突提示是否在屏幕上显示通知 |
| `rememberSpeed` | `true` | 调速后自动把当前倍速写回 `config.json` |
| `toggleRestoresSpeed` | `true` | 切回 `1.0x` 后再按一次 `toggleKey` 恢复切换前的倍率 |
| `repeatInterval` | `0.15` | 按住快捷键连续调速的间隔（秒），`0` 表示只触发一次 |
| `allowCoexist` | `false` | 是否允许与内置 `SpeedHackMod` 共存（默认 `false`，检测到即报错并停用本模组） |
| `turnClockEnabled` | `true` | 内置回合时钟总开关 |
| `turnClockOtherPlayers` | `true` | 别人回合头顶倒计时是否按真实时间显示 |
| `turnClockHeroSelect` | `true` | 选人界面倒计时补偿 |
| `turnClockSettlement` | `true` | 结算界面倒计时补偿 |
| `turnClockRoomWait` | `true` | 房间等待倒计时补偿 |
| `turnClockStoryAuto` | `true` | 剧情自动播放倒计时补偿 |
| `turnClockLogWindow` | `true` | 每次倒计时窗口结束时记录实际时间与补偿次数摘要 |

## 本地构建与打包

```powershell
pwsh -File tools\fetch-refs.ps1 -Source C:\src\Study\astralparty\modding\msvc
pwsh -File tools\package.ps1
```
