# 文言（华夏）语言包（ClassicalChineseMod）

参考 Minecraft 的「文言（华夏）」，为《吉星派对》国服客户端添加完整的**简体字形文言文**语言包，不修改游戏原始资源文件。

## 前置要求

- **CesiumLoader**（[higashitaniyume/CesiumLoader](https://github.com/higashitaniyume/CesiumLoader)）
- **多语言支持（`LanguageUnlockMod` >= 1.0.0）**：需处于启用状态（位于 `AstralParty_ModLoader/mods/LanguageUnlockMod/`，而非 `disabled_mods/`）。

## 安装方法

1. 将本压缩包中的 `ClassicalChineseMod` 文件夹解压到游戏目录下的：
   ```text
   <游戏目录>\AstralParty_ModLoader\mods\ClassicalChineseMod\
   ```
2. 确认前置模组 `LanguageUnlockMod` 已在 `AstralParty_ModLoader\mods\` 中启用。
3. 正常启动游戏，模组初始化后会自动重登一次并加载 **文言（华夏）**。

## 使用与切换

- 在游戏内打开 **设定（设置）→ 画面（屏幕）→ 语言**，可在 **简体中文 / English / 日本語 / 繁體中文 / 文言（华夏）** 之间自由切换。
- 也可在 `ClassicalChineseMod/config.json` 中调整：
  - `enabled`：总开关（默认 `true`）
  - `active`：启动时是否默认激活文言（华夏）（默认 `true`；在游戏内切换为其他语言时会自动更新）

## 特性说明

- 收录 1,528 条 FairyGUI 界面文案（`data/lzh.xml`）与 6,661 条配置正文词条（`data/lzh.pack`），覆盖菜单、技能、卡牌、角色、遗物、道具、任务、剧情与系统提示。
- 正文按简中原文匹配，游戏后续热更新即使新增或重排词条编号，已有译文仍自动生效，未译新词条自动保留简中原文，不会空白。
- 字体、首页 Banner、活动入口、Logo 与公告沿用国服原生简中资源，不会出现缺字或入口消失。
